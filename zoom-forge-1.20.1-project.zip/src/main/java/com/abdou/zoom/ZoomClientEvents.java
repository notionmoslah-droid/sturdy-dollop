package com.abdou.zoom;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ZoomMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ZoomClientEvents {
    private static final double MIN = 1.25;
    private static final double MAX = 30.0;
    private static final double STEP = 1.25;

    private static boolean zooming = false;
    private static double target = 3.0;
    private static double current = 1.0;

    private static KeyMapping toggleKey;
    private static KeyMapping inKey;
    private static KeyMapping outKey;

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        toggleKey = new KeyMapping("key.zoom.toggle", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_C, "category.zoom");
        inKey = new KeyMapping("key.zoom.in", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_B, "category.zoom");
        outKey = new KeyMapping("key.zoom.out", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_T, "category.zoom");

        event.register(toggleKey);
        event.register(inKey);
        event.register(outKey);
    }

    private static double factor() {
        double goal = zooming ? target : 1.0;
        current += (goal - current) * 0.25;
        if (Math.abs(goal - current) < 0.001) {
            current = goal;
        }
        return current;
    }

    @Mod.EventBusSubscriber(modid = ZoomMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeEvents {
        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent.Post event) {
            if (toggleKey == null) return;

            while (toggleKey.consumeClick()) {
                zooming = !zooming;
            }
            while (inKey.consumeClick()) {
                zooming = true;
                target = Math.min(MAX, target * STEP);
            }
            while (outKey.consumeClick()) {
                target = Math.max(MIN, target / STEP);
            }
        }

        @SubscribeEvent
        public static void onComputeFov(ViewportEvent.ComputeFov event) {
            double f = factor();
            if (f > 1.0001) {
                event.setFOV(event.getFOV() / f);
            }
        }
    }
}
