package com.abdou.zoom;

import net.minecraftforge.fml.common.Mod;

@Mod(ZoomMod.MOD_ID)
public class ZoomMod {
    public static final String MOD_ID = "zoom";

    public ZoomMod() {
        // The zoom controls are registered by the client-only event subscriber.
    }
}
