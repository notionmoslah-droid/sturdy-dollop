package com.abdou.zoom;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ZoomMod implements ClientModInitializer {
    private static final double MIN = 1.25, MAX = 30.0, STEP = 1.25;

    private static boolean zooming = false;
    private static double target = 3.0;   // zoom level when active
    private static double current = 1.0;  // smoothed value actually applied

    private static KeyBinding toggleKey, inKey, outKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zoom.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.zoom"));
        inKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zoom.in", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.zoom"));
        outKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zoom.out", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_T, "category.zoom"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) zooming = !zooming;
            while (inKey.wasPressed()) {
                zooming = true;
                target = Math.min(MAX, target * STEP);
            }
            while (outKey.wasPressed()) {
                target = Math.max(MIN, target / STEP);
            }
        });
    }

    /** Called every frame from the renderer; returns the FOV divisor (1.0 = no zoom). */
    public static double factor() {
        double goal = zooming ? target : 1.0;
        current += (goal - current) * 0.25;
        if (Math.abs(goal - current) < 0.001) current = goal;
        return current;
    }
}
