Zoom (Fabric 1.20.1, client-side)
Keys (changeable in Controls > Zoom):
  C = toggle zoom   B = zoom in (also turns zoom on)   T = zoom out

Build (Java 17 required):
  gradle wrapper --gradle-version 8.5     # once, if no gradlew present
  ./gradlew build
Jar: build/libs/zoom-1.0.0.jar  -> put in .minecraft/mods with Fabric API
