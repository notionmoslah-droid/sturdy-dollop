ZOOM - Forge 1.20.1
====================

This is the Forge conversion of the supplied Fabric Zoom mod source.

Minecraft: 1.20.1
Forge: 47.2.0
Java: 17

Controls (changeable in Options > Controls > Key Binds > Zoom):
  C = Toggle zoom
  B = Zoom in (also enables zoom)
  T = Zoom out

Build with GitHub Actions:
  1. Upload the contents of this project to the root of your GitHub repository.
  2. Open the Actions tab.
  3. Run "Build Minecraft Forge Mod", or push a commit to main.
  4. Download the "zoom-forge-1.20.1" artifact from the completed workflow run.

The workflow installs Gradle and runs `gradle build`; it does not expect a
gradlew wrapper file.

The resulting JAR is client-side. Install it in the mods folder of a Forge
1.20.1 client. It is not a server-only mod.
