package com.abdou.zoom;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(
        modid = ZoomMod.MOD_ID,
        value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.MOD
)
public final class ZoomClientEvents {
    private static final double MIN_ZOOM = 1.25;
    private static final double MAX_ZOOM = 30.0;
    private static final double ZOOM_STEP = 1.25;

    private static boolean zooming = false;
    private static double targetZoom = 3.0;
    private static double currentZoom = 1.0;

    private static KeyMapping toggleKey;
    private static KeyMapping zoomInKey;
    private static KeyMapping zoomOutKey;

    private ZoomClientEvents() {}

    @SubscribeEvent
    public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
        toggleKey = new KeyMapping(
                "key.zoom.toggle",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "key.categories.zoom"
        );
        zoomInKey = new KeyMapping(
                "key.zoom.in",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                "key.categories.zoom"
        );
        zoomOutKey = new KeyMapping(
                "key.zoom.out",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_T,
                "key.categories.zoom"
        );

        event.register(toggleKey);
        event.register(zoomInKey);
        event.register(zoomOutKey);
    }

    private static void handleKeyPresses() {
        if (toggleKey == null) {
            return;
        }

        while (toggleKey.consumeClick()) {
            zooming = !zooming;
        }

        while (zoomInKey.consumeClick()) {
            zooming = true;
            targetZoom = Math.min(MAX_ZOOM, targetZoom * ZOOM_STEP);
        }

        while (zoomOutKey.consumeClick()) {
            targetZoom = Math.max(MIN_ZOOM, targetZoom / ZOOM_STEP);
        }
    }

    private static double getSmoothedZoom() {
        double desiredZoom = zooming ? targetZoom : 1.0;
        currentZoom += (desiredZoom - currentZoom) * 0.25;

        if (Math.abs(desiredZoom - currentZoom) < 0.001) {
            currentZoom = desiredZoom;
        }

        return currentZoom;
    }

    @Mod.EventBusSubscriber(
            modid = ZoomMod.MOD_ID,
            value = Dist.CLIENT,
            bus = Mod.EventBusSubscriber.Bus.FORGE
    )
    public static final class ForgeEvents {
        private ForgeEvents() {}

        @SubscribeEvent
        public static void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase == TickEvent.Phase.END) {
                handleKeyPresses();
            }
        }

        @SubscribeEvent
        public static void onComputeFov(ViewportEvent.ComputeFov event) {
            double zoom = getSmoothedZoom();
            if (zoom > 1.0001) {
                event.setFOV(event.getFOV() / zoom);
            }
        }
    }
}
