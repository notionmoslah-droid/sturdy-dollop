package com.abdou.zoom;

import net.minecraftforge.fml.common.Mod;

@Mod(ZoomMod.MOD_ID)
public final class ZoomMod {
    public static final String MOD_ID = "zoom";

    public ZoomMod() {
        // The zoom feature is client-side and is registered in ZoomClientEvents.
    }
}
